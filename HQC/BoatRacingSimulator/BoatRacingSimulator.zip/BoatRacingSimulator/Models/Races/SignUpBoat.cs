﻿namespace BoatRacingSimulator.Models.Races
{
    using Interfaces;

    public class SignUpBoat : IModelable
    {
        public string Model { get; }
    }
}