﻿namespace BoatRacingSimulator.Interfaces
{
    public interface IHorsepower
    {
         int Horsepower { get; }
    }
}