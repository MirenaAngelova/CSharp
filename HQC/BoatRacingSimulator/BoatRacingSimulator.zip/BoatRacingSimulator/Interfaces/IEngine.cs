﻿namespace BoatRacingSimulator.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}