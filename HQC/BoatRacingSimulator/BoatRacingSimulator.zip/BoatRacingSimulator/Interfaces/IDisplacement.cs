﻿namespace BoatRacingSimulator.Interfaces
{
    public interface IDisplacement
    {
        int Displacement { get; }
    }
}