﻿namespace BoatRacingSimulator.Interfaces
{
    public interface IBoatEngine : IModelable, IHorsepower, IDisplacement
    {
    }
}