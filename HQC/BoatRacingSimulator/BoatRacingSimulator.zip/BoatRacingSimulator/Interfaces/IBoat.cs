﻿namespace BoatRacingSimulator.Interfaces
{
    public interface IBoat : IModelable, IWeightable
    {
    }
}