namespace ChepelareHotelBookingSystem3.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}