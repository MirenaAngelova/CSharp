namespace ChepelareHotelBookingSystem3.Interfaces
{
    public interface IDbEntity
    {
        int Id { get; set; }
    }
}