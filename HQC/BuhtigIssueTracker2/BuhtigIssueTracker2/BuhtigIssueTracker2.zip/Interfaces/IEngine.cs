namespace BuhtigIssueTracker2.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}