﻿namespace BuhtigIssueTracker2.Stuff
{
    public enum Role
    {
        Guest,
        User
    }
}