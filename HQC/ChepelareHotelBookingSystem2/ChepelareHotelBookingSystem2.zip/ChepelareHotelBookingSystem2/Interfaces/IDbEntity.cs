namespace ChepelareHotelBookingSystem2.Interfaces
{
    public interface IDbEntity
    {
        int Id { get; set; }
    }
}