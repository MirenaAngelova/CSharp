namespace ChepelareHotelBookingSystem2.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}