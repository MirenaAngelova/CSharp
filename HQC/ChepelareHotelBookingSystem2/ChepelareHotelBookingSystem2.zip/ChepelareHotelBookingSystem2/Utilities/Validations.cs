﻿namespace ChepelareHotelBookingSystem2.Utilities
{
    public class Validations
    {
        public const int MinLengthUsername = 5;
        public const int MinLengthPassword = 6;
        public const int MinLengthVenueName = 3;
        public const int MinLengthVenueAddress = 3;
    }
}
