﻿namespace ChepelareHotelBookingSystem2.Models
{
    public enum Roles
    {
        User,
        VenueAdmin
    }
}
