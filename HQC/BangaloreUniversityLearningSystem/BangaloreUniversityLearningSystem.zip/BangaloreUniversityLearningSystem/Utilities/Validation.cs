﻿namespace BangaloreUniversityLearningSystem.Utilities
{
    public class Validation
    {
        public const int MinLengthUsername = 5;
        public const int MinLengthPassword = 6;
        public const int MinLengthLectureName = 3;
        public const int MinLengthCourseName = 5;
    }
}
