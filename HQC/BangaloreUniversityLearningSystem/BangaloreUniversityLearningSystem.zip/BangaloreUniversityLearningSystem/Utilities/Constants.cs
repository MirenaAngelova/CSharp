﻿namespace BangaloreUniversityLearningSystem.Utilities
{
    public static class Constants
    {
        public const string DotSeparator = ".";
        public const string Controller = "Controller";
        public const string Views = "Views";
    }
}
