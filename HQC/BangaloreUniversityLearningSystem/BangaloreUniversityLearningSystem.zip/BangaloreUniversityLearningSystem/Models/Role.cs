﻿namespace BangaloreUniversityLearningSystem.Models
{
    public enum Role
    {
        Student,
        Lecturer,
        Guest
    }
}