﻿namespace Empires6.Enums
{
    public enum ResourceType
    {
        Gold,
        Steel
    }
}