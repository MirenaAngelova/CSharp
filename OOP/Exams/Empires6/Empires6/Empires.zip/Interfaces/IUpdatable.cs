﻿namespace Empires6.Interfaces
{
    public interface IUpdatable
    {
        void Update();
    }
}