﻿namespace Empires6.Interfaces
{
    public interface IUnit :IHealth, IAttack
    {
    }
}