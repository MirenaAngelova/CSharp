﻿namespace Empires6.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}