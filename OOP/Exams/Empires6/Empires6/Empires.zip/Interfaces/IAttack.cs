﻿namespace Empires6.Interfaces
{
    public interface IAttack
    {
        int Damage { get; } 
    }
}