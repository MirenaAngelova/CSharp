﻿namespace Empires6.Interfaces
{
    public interface IBuilding : IUnitProduced, IResourceProduced, IUpdatable
    {
    }
}