﻿namespace Empires6.Interfaces
{
    public interface IInputReader
    {
        string ReadLine();
    }
}