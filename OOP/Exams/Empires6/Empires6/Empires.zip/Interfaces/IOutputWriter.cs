﻿namespace Empires6.Interfaces
{
    public interface IOutputWriter
    {
        void WriteLine(string output);
    }
}