﻿namespace Empires6.Interfaces
{
    public interface IHealth
    {
        int Health { get; set; } 
    }
}