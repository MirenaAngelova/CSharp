﻿namespace Blobs2.Interfaces
{
    public interface IOutputWriter
    {
        void Write(string output);
    }
}