﻿namespace Blobs2.Interfaces
{
    public interface IAttacker
    {
        void PerformAttack(IBlob target);
    }
}