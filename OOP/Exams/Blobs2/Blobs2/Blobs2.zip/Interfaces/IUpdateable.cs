﻿namespace Blobs2.Interfaces
{
    public interface IUpdateable
    {
        void Update();
    }
}