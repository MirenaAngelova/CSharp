﻿namespace Blobs2.Interfaces
{
    public interface IInputReader
    {
        string ReadLine();
    }
}