﻿namespace Empires.Interfaces
{
    public interface IAttacker
    {
        int AttackDamage { get; } 
    }
}