﻿namespace Empires.Interfaces
{
    public interface IRunnable
    {
        void Run();
    }
}