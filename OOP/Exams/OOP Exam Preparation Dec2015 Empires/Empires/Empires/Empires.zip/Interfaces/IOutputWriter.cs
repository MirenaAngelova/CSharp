﻿namespace Empires.Interfaces
{
    public interface IOutputWriter
    {
        void Print(string message);
    }
}