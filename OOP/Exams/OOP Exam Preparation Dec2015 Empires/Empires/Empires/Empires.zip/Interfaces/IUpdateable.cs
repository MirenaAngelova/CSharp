﻿namespace Empires.Interfaces
{
    public interface IUpdateable
    {
        void Update();
    }
}