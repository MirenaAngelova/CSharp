﻿namespace Empires.Interfaces
{
    public interface IInputReader
    {
        string ReadLine();
    }
}