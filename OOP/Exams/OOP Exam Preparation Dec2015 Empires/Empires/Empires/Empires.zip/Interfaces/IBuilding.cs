﻿namespace Empires.Interfaces
{
    public interface IBuilding : IUnitProducer, IResourceProducer, IUpdateable
    {
    }
}