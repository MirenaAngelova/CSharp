﻿namespace Empires.Interfaces
{
    public interface IUnit:IAttacker, IDestroyable
    {
    }
}