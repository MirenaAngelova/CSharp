﻿namespace Capitalism.Interfaces
{
    public interface IUserInterface : IReader, IWriter
    {
    }
}