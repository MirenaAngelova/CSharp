﻿namespace Capitalism.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}